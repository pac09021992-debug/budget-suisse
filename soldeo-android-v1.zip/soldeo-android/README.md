# SOLDEO

Ton reste à vivre, simplement.

Projet Android basé sur Capacitor. Le prototype web stable est dans `www/index.html`.

## Générer l'application Android

1. Installer Node.js et Android Studio.
2. Dans ce dossier : `npm install`
3. Puis : `npx cap add android`
4. Puis : `npx cap sync android`
5. Puis : `npx cap open android`

L'APK de test peut ensuite être généré depuis Android Studio.
